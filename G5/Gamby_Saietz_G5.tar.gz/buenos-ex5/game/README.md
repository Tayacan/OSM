Let's make an ASCII game for buenos.
