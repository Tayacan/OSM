#ifndef GAME_CONFIG
#define GAME_CONFIG

#define LINES  41
#define WIDTH  15
#define HEIGHT 8

#endif
